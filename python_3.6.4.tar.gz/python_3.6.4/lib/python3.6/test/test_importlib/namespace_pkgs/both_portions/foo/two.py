attr = 'both_portions foo two'
